//Primero creamos la clase

class Estudiante {
    //Definimos la variables protegidas
    #edad;
    #nombre;
    #nota;

    constructor(nombre, edad, nota) {

        // Mantengo tu intención: llamar a los setters
        this.setNombre(nombre);
        this.setEdad(edad);
        this.setnota(nota);
    }

    //Setter
    setNombre(nombre) {
        if (nombre.trim() == "") {
            console.log("Debe ingresar un dato valido");
            return;
        }
        this.#nombre = nombre;
    }

    setEdad(edad) {
        if (edad < 12) {
            console.log("No cumple la edad minima");
            return;
        }
        this.#edad = edad;
    }

    setnota(nota) {
        if (nota < 0 || nota > 100) {
            console.log("Nota esta fuera de rango");
            return;
        }
        this.#nota = nota;
    }

    //GETTERS
    getNombre() {
        return this.#nombre;
    }

    getEdad() {
        return this.#edad;
    }

    getNota() {
        return this.#nota;
    }
}

// Crear estudiante
const estudiante1 = new Estudiante("Juan", 12, 100);

console.log("La nota de " + estudiante1.getNombre() + " es " + estudiante1.getNota());