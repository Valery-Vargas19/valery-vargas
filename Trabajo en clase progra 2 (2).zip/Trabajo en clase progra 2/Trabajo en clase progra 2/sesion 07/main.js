import Auto from "./Auto.js"
 
 
const auto1 = new Auto();
console.log ( "Estado del auto", auto1.verEstado() );
 
auto1.encender();
 
console.log("Estado encendido del autondespues de encederlo", auto1.verEstado() );