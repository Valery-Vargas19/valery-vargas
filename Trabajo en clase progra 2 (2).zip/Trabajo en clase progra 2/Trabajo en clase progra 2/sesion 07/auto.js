export default class Auto {
 
#velocidad;
#isEncendido
 
 
    constructor() {
this.#velocidad=0
this.#isEncendido=false
    }
 
encender () {
 
this.#isEncendido=true;
 
}
 
acelerar(cantidad) {
this.#velocidad = this.#velocidad + cantidad
}
verEstado () {
return this.#isEncendido
}
 
if (condition) {
   
}
 
}