import PruebaCajero from "./PruebaCajero.js"

const cj = new PruebaCajero(1234, 8000);

console.log("Saldo actual", cj.saldo);

//cj.setSaldo(2000);
cj.Saldo = 4000;

console.log("Saldo actual despues del deposito", cj.saldo);

