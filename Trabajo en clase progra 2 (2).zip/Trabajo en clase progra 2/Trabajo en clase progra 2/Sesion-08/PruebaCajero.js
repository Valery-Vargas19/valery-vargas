export default class PruebaCajero {
    #saldo = 0;
    #pin;

  constructor(pin, monto) {
    this.#pin = pin;
    this.Saldo = monto; // usa el setter correctamente
}


    dispensarDinero(montoAnterior) {

        if (montoAnterior > this.#saldo) {
            throw new Error("Fondos insuficientes");
        }

        this.#saldo = this.#saldo - montoAnterior;

        return montoAnterior;
    }

    set Saldo(monto) {

        if (isNaN(monto)) {
            throw new Error("Debe ingresar datos numericos");
        }

        this.#saldo = this.#saldo + monto;
    }

    get saldo() {
        return this.#saldo;
    }
}

