import { Router } from "express"
import operacionesMatematicas from "../clase/operacionesMatematicas.js"

const router = Router()
const operaciones = new operacionesMatematicas()

router.get("/sumar/:num1/:num2", (req, res) => {

  const num1 = Number(req.params.num1)
  const num2 = Number(req.params.num2)

  const respuesta = operaciones.sumar(num1, num2)

  res.json({
    "tipo de operacion": "suma",
    "Numero 1": num1,
    "Numero 2": num2,
    "resultado": respuesta
  })
})

export default router