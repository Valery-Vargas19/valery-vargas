import express from "express"
import router from "./routes/mate.routes.js"

const app = express()
const port = 3000

app.use("/mate", router)

app.get('/', (req, res) => {
  res.send('<h1>Servidor de operaciones matematicas</h1>')
})

app.listen(port, () => {
  console.log(`Example app listening on port ${port}`)
})