export default class operacionesMatematicas {

  sumar(a, b) {
    return a + b
  }

  restar(a, b) {
    return a - b
  }

}