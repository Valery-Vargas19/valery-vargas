import express from "express"
const app = express()
const port = 3000
 
const usuarios = [
    {
        id: "123",
        nombre: "Juanita",

    },
    {
        id: "456",
        nombre: "Pepito"
    },
];

app.get('/', (req, res) => {
  res.json(usuarios)
})
 
app.listen(port, () => {
  console.log(`Example app listening on port ${port}`)
})
