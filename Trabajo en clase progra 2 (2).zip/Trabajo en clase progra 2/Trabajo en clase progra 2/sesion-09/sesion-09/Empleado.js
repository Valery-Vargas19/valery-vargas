class Empleado {
  constructor(nombre, horasTrabajadas, pagoPorHora) {
    this.nombre = nombre;
    this.horasTrabajadas = horasTrabajadas;
    this.pagoPorHora = pagoPorHora;
  }

  mostrarInformacion() {
    return `Empleado: ${this.nombre}`;
  }

  calcularSalario() {
    return this.horasTrabajadas * this.pagoPorHora;
  }
}

module.exports = Empleado;
