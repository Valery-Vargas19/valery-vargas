const Empleado = require("./Empleado.js");

class EmpleadoPorHoras extends Empleado {
  constructor(nombre, horasTrabajadas, pagoPorHora = 15) {
    super(nombre, horasTrabajadas, pagoPorHora);
  }

  mostrarInformacion() {
    return `${super.mostrarInformacion()} - Por Horas - Horas Trabajadas: ${this.horasTrabajadas}h - Pago por Hora: $${this.pagoPorHora}`;
  }

  calcularSalario() {
    return super.calcularSalario();
  }
}

module.exports = EmpleadoPorHoras;
