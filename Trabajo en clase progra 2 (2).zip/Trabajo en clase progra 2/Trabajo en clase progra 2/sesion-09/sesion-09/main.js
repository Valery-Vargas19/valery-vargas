const EmpleadoTiempoCompleto = require("./EmpleadoTiempoCompleto.js");
const EmpleadoPorHoras = require("./EmpleadoPorHoras.js");

const nuevoEmpleadoTiempoCompleto = new EmpleadoTiempoCompleto("Juan", 2500);
const nuevoEmpleadoPorHoras = new EmpleadoPorHoras("Joaquin", 20);

console.info( nuevoEmpleadoTiempoCompleto.mostrarInformacion() );
console.info( nuevoEmpleadoTiempoCompleto.calcularSalario() );

console.info( nuevoEmpleadoPorHoras.mostrarInformacion() );
console.info( nuevoEmpleadoPorHoras.calcularSalario() );
