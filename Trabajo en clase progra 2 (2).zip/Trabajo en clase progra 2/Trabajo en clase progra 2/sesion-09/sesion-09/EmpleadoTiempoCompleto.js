const Empleado = require("./Empleado.js");

class EmpleadoTiempoCompleto extends Empleado {
  constructor(nombre = "Empleado", salarioMensual = 2000) {
    super(nombre, 0, 0);
    this.salarioMensual = salarioMensual;
  }

  mostrarInformacion() {
    return `${super.mostrarInformacion()} - Tiempo Completo - Salario Mensual: $${this.salarioMensual}`;
  }

  calcularSalario() {
    return this.salarioMensual;
  }
}

module.exports = EmpleadoTiempoCompleto;
