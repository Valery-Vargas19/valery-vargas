//Definir el npmbre de la clase, debe ir en mayuscula
class Persona {

    //Definir el constructor
    constructor(nombre, edad) {
        //Definimos las propiedades de la clase
        this.profesion = " estudiante ";
        this.edad = edad;
    }
    //Definir los metodos:
    saludar() {
        console.log(
            "Hola a todos!!! Mi nombre es " +   this.nombre + ", y mi edad es  "    + this.edad
        + " años Mi profesion es " +   this.profesion
        );   
        
    }

}

//çreación del array (arreglo) de personas "directorio"

//se define como cualquier variable o constante 
const directorio = [
    new Persona ("Ana", 25),
    new Persona ("Lolita", 84),
    new Persona ("Enrique iglesias", 52)
];

//console.log(directorio);

//recorrer el arreglo y llamara al metodo de persona (saludar)
/*
directorio[0].saludar()
directorio[1].saludar()
directorio[2].saludar()
*/
//Recorrido  del Arry con un ciclo for of

for (const persona of directorio) {
    
    persona.saludar()
}


