//Definir el npmbre de la clase, debe ir en mayuscula
class Persona {

    //Definir el constructor
    constructor(nombre, edad) {
        //Definimos las propiedades de la clase
        this.profesion = " estudiante ";
        this.edad = edad;
    }
    //Definir los metodos:
    saludar() {
        console.log(
            "Hola a todos!!! Mi nombre es " +   this.nombre + ", y mi edad es  "    + this.edad
        + " años Mi profesion es " +   this.profesion
        );   
        
    }

}

//para poder usar nuestra clase debemos instanciar o crear el objeto a partir de la clase
const persona1 = new Persona("Panchito", 17)
const persona2 = new Persona("Pepita", 35)

//para que se ejecute el metodo deseado se escribe el nombre del objeto, se agrga punto y seguido
//el comporamiento o accion que se desea ejecutar

persona1.saludar()
persona2.saludar()