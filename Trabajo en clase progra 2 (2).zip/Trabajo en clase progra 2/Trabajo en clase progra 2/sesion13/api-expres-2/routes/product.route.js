import { Router } from "express";
import ProductController from "../controllers/ProductController";
import ProductController from "../controllers/ProductController";

const router = Router
const ProductController = new ProductController();


//establecer ruta
router.get("/productos", (req, res) => ProductController.index (req, res));
router.get("/productos/:id", (req, res) => ProductController.show (req, res));
router.post("/productos", (req, res) => ProductController.create (req, res));

//router.delete eliminar
//router.put actualizar

export default router



