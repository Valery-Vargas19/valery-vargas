import express from "express";
import productRoutes from "./routes/producto.routes.js"
 
const app = express();
const PORT = 3000;
 
 
//Middleware 
app.use(express.json());
 
 
// Ruta de los productos
app.use( productRoutes  )
 
app.listen (  PORT, ()=> {
    console.log("Servidor levantado en el puerto", PORT );
}    )