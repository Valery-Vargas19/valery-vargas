class Estudiante {
    #nombre;
    #edad;
    #nota;

    constructor(nombre, edad, nota) {
        this.setNombre(nombre);
        this.setEdad(edad);
        this.setNota(nota);
    }

    setNombre(nombre) {
        if (typeof nombre !== "string" || nombre.trim() === "") {
            throw new Error("El nombre no es valido");
        }
        this.#nombre = nombre;
    }

    swtEdad(edad) {   // ← Mantengo tu nombre original
        if (!Number.isInteger(edad)) {
            throw new Error("formato de la edad no es valido");
        }
        if (edad < 12) {
            throw new Error("Edad minima no pemitida");
        }
        this.#edad = edad;
    }

    setEdad(edad) {   // ← Este método es necesario porque lo llamas en el constructor
        this.swtEdad(edad); // ← Llama a tu método original sin cambiarlo
    }

    setNota(nota) {
        if (!Number.isFinite(nota)) {
            throw new Error("dato no valido");
        }
        if (nota < 0 || nota > 100) {
            throw new Error("Nota fuera de rengo");
        }
        this.#nota = nota;
    }

    // Getters
    getNombre() {
        return this.#nombre || "No asignado";
    }

    getEdad() {
        return this.#edad;
    }

    getNota() {
        return this.#nota;
    }
}

// utilizar la clase Estudiante version 2
try {
    const estudiante1 = new Estudiante("Juanita", 20, 95); // p5 no existe, lo reemplazo por un número válido
    console.log(estudiante1.getNombre()); // faltaban los paréntesis
} catch (error) {
    console.log("Eror al crear objeto", error.message);
}